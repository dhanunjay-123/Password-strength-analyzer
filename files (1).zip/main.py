"""
main.py — Password Analyzer CLI v2

Usage:
  python main.py                            # interactive (hidden input)
  python main.py -p "MyP@ssw0rd!"          # inline
  python main.py -p "test" --hibp          # + HaveIBeenPwned check
  python main.py -p "test" --suggest       # show stronger alternatives
  python main.py -p "test" -u alice        # check reuse for user 'alice'
  python main.py -p "test" -u alice --save # save hash to vault
  python main.py --generate                # generate strong passwords only
  python main.py --batch passwords.txt     # bulk file analysis
  python main.py --history                 # show past analyses
  python main.py --stats                   # aggregate stats
  python main.py -p "test" --json          # full JSON output
"""

import argparse
import getpass
import json
import sys
from pathlib import Path

from strength_checker import analyze
from entropy import entropy_report
from wordlist_checker import wordlist_report, check_hibp_api
from password_generator import suggest_alternatives, generate_random, generate_passphrase
from database import (
    init_db, save_result, get_history, get_stats,
    was_used_before, remember_password,
)

# ── terminal colours ────────────────────────────────────────────────────────
C = {
    "red":    "\033[91m", "yellow": "\033[93m",
    "green":  "\033[92m", "cyan":   "\033[96m",
    "bold":   "\033[1m",  "reset":  "\033[0m",
}
def clr(col, text): return C.get(col, "") + str(text) + C["reset"]

LABEL_COL = {
    "Very Weak": "red", "Weak": "red",
    "Fair": "yellow", "Strong": "green", "Very Strong": "green",
}
def divider(): print(clr("bold", "━" * 56))


# ── full report ─────────────────────────────────────────────────────────────
def print_report(password, hibp=False, username=None, save=False, suggest=False):
    result  = analyze(password)
    entropy = entropy_report(password)
    wl      = wordlist_report(password)
    lc      = LABEL_COL.get(result["label"], "cyan")

    print()
    divider()
    print(clr("bold", "  PASSWORD STRENGTH REPORT  v2"))
    divider()
    score_str = str(result["score"]) + "/100"
    print("  Score     : " + clr(lc, score_str) + "  [" + clr(lc, result["label"]) + "]")
    print("  Length    : " + str(result["password_length"]) + " characters")
    print("  Charset   : pool of " + str(result["charset_size"]) + " characters")
    print()

    print(clr("bold", "  ENTROPY"))
    print("  Bit entropy      : " + str(entropy["bit_entropy"]) + " bits")
    print("  Shannon entropy  : " + str(entropy["shannon_entropy"]))
    print("  Unique chars     : " + str(entropy["unique_chars"]) + "  (ratio " + str(entropy["uniqueness_ratio"]) + ")")
    print("  Rating           : " + entropy["rating"])
    print()

    print(clr("bold", "  CRACK TIME"))
    ct = result["crack_time"]
    print("  Online  (1K /s)  : " + ct["online_attack_1k_per_sec"])
    print("  Offline (10B/s)  : " + ct["offline_hash_10b_per_sec"])
    print("  GPU     ( 1T/s)  : " + ct["gpu_cluster_1t_per_sec"])
    print()

    print(clr("bold", "  POLICY CHECKS"))
    for ch in result["policy_checks"]:
        icon = clr("green", "✔") if ch["passed"] else clr("red", "✘")
        print("  " + icon + "  " + ch["description"])
    print()

    if result["suggestions"]:
        print(clr("bold", "  TO IMPROVE"))
        for s in result["suggestions"]:
            print("  •  " + s)
        print()

    print(clr("bold", "  WORDLIST / BREACH"))
    common_str = clr("red", "Yes — HIGH RISK") if wl["is_common_password"] else "No"
    weak_str   = clr("yellow", "Yes") if wl["matches_weak_pattern"] else "No"
    print("  Common password  : " + common_str)
    print("  Weak pattern     : " + weak_str)

    if hibp:
        print("  HIBP check … ", end="", flush=True)
        r = check_hibp_api(password)
        if r["count"] == -1:
            print(clr("yellow", "Error — " + r.get("error", "offline")))
        elif r["breached"]:
            print(clr("red", "BREACHED — seen " + str(r["count"]) + " times in data dumps!"))
        else:
            print(clr("green", "Not found in breach database."))
    print()

    if username:
        reused = was_used_before(username, password)
        print(clr("bold", "  REUSE CHECK"))
        if reused:
            print(clr("red", "  ✘  This password was used before by '" + username + "'!"))
        else:
            print(clr("green", "  ✔  Not in vault for '" + username + "'."))
            if save:
                remember_password(username, password)
                print(clr("cyan", "  ✔  Password hash saved to vault."))
        print()

    if suggest:
        print(clr("bold", "  SUGGESTED ALTERNATIVES"))
        for alt in suggest_alternatives(password, count=3):
            print("  [" + alt["strategy"] + "]")
            print("    " + clr("cyan", alt["password"]))
            print("    " + alt["rationale"])
        print()

    divider()
    print()
    save_result(password, result["score"], result["label"], result["policy_checks"])


# ── batch mode ───────────────────────────────────────────────────────────────
def batch_mode(filepath):
    try:
        lines = Path(filepath).read_text().splitlines()
    except FileNotFoundError:
        print(clr("red", "File not found: " + filepath))
        sys.exit(1)

    passwords = [l.strip() for l in lines if l.strip()]
    print(clr("bold", "\nAnalyzing " + str(len(passwords)) + " password(s)…\n"))
    for pwd in passwords:
        r      = analyze(pwd)
        e      = entropy_report(pwd)
        lc     = LABEL_COL.get(r["label"], "cyan")
        masked = pwd[:2] + "*" * max(0, len(pwd) - 2)
        lbl    = r["label"].ljust(12)
        score  = str(r["score"]).rjust(3)
        bits   = str(e["bit_entropy"]).rjust(6)
        print("  " + masked.ljust(22) + " " + clr(lc, lbl) +
              "  score=" + score + "/100  entropy=" + bits + " bits")
        save_result(pwd, r["score"], r["label"])


# ── main ─────────────────────────────────────────────────────────────────────
def main():
    parser = argparse.ArgumentParser(description="Password Analyzer v2")
    parser.add_argument("-p",  "--password",  help="Password to analyze")
    parser.add_argument("-u",  "--username",  help="Username for reuse check")
    parser.add_argument("-b",  "--batch",     help="File with one password per line")
    parser.add_argument("--hibp",     action="store_true", help="HaveIBeenPwned API lookup")
    parser.add_argument("--suggest",  action="store_true", help="Show stronger alternatives")
    parser.add_argument("--save",     action="store_true", help="Save password hash to vault")
    parser.add_argument("--generate", action="store_true", help="Generate strong passwords")
    parser.add_argument("--history",  action="store_true", help="Show analysis history")
    parser.add_argument("--stats",    action="store_true", help="Aggregate stats")
    parser.add_argument("--json",     action="store_true", help="Full JSON output")
    args = parser.parse_args()

    init_db()

    if args.history:
        rows = get_history()
        print(clr("bold", "\nLast " + str(len(rows)) + " analyses:\n"))
        for row in rows:
            lc = LABEL_COL.get(row["label"], "cyan")
            sc = str(row["score"]).rjust(3) + "/100"
            print("  [" + row["timestamp"] + "]  " + clr(lc, sc) + "  " + row["label"])
        return

    if args.stats:
        s = get_stats()
        print(clr("bold", "\nAggregate stats:\n"))
        print("  Total analyzed : " + str(s["total"]))
        print("  Avg score      : " + str(s["avg_score"]) + "/100")
        print("  Min / Max      : " + str(s["min_score"]) + " / " + str(s["max_score"]))
        print("  Distribution   :")
        for label, cnt in s["label_distribution"].items():
            bar = "█" * cnt
            print("    " + label.ljust(12) + " " + bar + " (" + str(cnt) + ")")
        return

    if args.generate:
        print(clr("bold", "\nGenerated passwords:\n"))
        print("  Random 16   : " + clr("cyan", generate_random(16)))
        print("  Random 20   : " + clr("cyan", generate_random(20)))
        print("  Passphrase  : " + clr("cyan", generate_passphrase(4)))
        print("  Passphrase  : " + clr("cyan", generate_passphrase(5, separator="_")))
        return

    if args.batch:
        batch_mode(args.batch)
        return

    password = args.password or getpass.getpass("Enter password to analyze: ")

    if args.json:
        report = {
            "analysis":     analyze(password),
            "entropy":      entropy_report(password),
            "wordlist":     wordlist_report(password),
            "alternatives": suggest_alternatives(password) if args.suggest else [],
        }
        print(json.dumps(report, indent=2))
        r = report["analysis"]
        save_result(password, r["score"], r["label"], r["policy_checks"])
    else:
        print_report(
            password,
            hibp=args.hibp,
            username=args.username,
            save=args.save,
            suggest=args.suggest,
        )


if __name__ == "__main__":
    main()
