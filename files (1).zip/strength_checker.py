"""
strength_checker.py — Scoring engine, policy checks, crack-time estimates
"""

import re
from entropy import bit_entropy, charset_size
from wordlist_checker import is_common_password


def has_repeating_chars(p: str) -> bool:
    return bool(re.search(r'(.)\1{2,}', p))

def has_sequential_pattern(p: str) -> bool:
    sequences = [
        "abcdefghijklmnopqrstuvwxyz",
        "qwertyuiopasdfghjklzxcvbnm",
        "01234567890",
    ]
    s = p.lower()
    for seq in sequences:
        for i in range(len(seq) - 2):
            chunk = seq[i:i+3]
            if chunk in s or chunk[::-1] in s:
                return True
    return False

def has_only_digits(p: str) -> bool:   return p.isdigit()
def has_only_letters(p: str) -> bool:  return p.isalpha()


POLICY_CHECKS = [
    ("length_8",     lambda p: len(p) >= 8,                           "At least 8 characters"),
    ("length_12",    lambda p: len(p) >= 12,                          "At least 12 characters (recommended)"),
    ("length_16",    lambda p: len(p) >= 16,                          "At least 16 characters (strong)"),
    ("uppercase",    lambda p: bool(re.search(r'[A-Z]', p)),          "Contains uppercase letter (A-Z)"),
    ("lowercase",    lambda p: bool(re.search(r'[a-z]', p)),          "Contains lowercase letter (a-z)"),
    ("digit",        lambda p: bool(re.search(r'[0-9]', p)),          "Contains digit (0-9)"),
    ("symbol",       lambda p: bool(re.search(r'[^a-zA-Z0-9]', p)),  "Contains special character (!@#$%)"),
    ("no_repeats",   lambda p: not has_repeating_chars(p),            "No repeating characters (aaa, 111)"),
    ("no_sequences", lambda p: not has_sequential_pattern(p),         "No sequential patterns (abc, 123, qwerty)"),
    ("not_common",   lambda p: not is_common_password(p),             "Not a known common/breached password"),
    ("high_unique",  lambda p: len(set(p)) / max(len(p),1) >= 0.6,   "High character uniqueness (≥60%)"),
]


def run_policy_checks(p: str) -> list[dict]:
    return [
        {"check": name, "description": desc, "passed": fn(p)}
        for name, fn, desc in POLICY_CHECKS
    ]


def calculate_score(p: str) -> int:
    if not p: return 0
    e = bit_entropy(p)
    base = min(100, int(e * 100 / 128))

    if is_common_password(p):           base = min(base, 8)
    if has_repeating_chars(p):          base = max(0, base - 15)
    if has_sequential_pattern(p):       base = max(0, base - 12)
    if has_only_digits(p):              base = max(0, base - 20)
    if has_only_letters(p):             base = max(0, base - 10)
    if len(p) < 6:                      base = max(0, base - 25)

    return max(0, min(100, base))


def strength_label(score: int) -> str:
    if score < 20: return "Very Weak"
    if score < 40: return "Weak"
    if score < 60: return "Fair"
    if score < 80: return "Strong"
    return "Very Strong"


def crack_time_estimate(p: str) -> dict:
    import math
    e = bit_entropy(p)
    guesses = 2 ** e

    def fmt(sec: float) -> str:
        if sec < 1:          return "< 1 second"
        if sec < 60:         return f"{int(sec)} second(s)"
        if sec < 3600:       return f"{int(sec/60)} minute(s)"
        if sec < 86400:      return f"{int(sec/3600)} hour(s)"
        if sec < 2592000:    return f"{int(sec/86400)} day(s)"
        if sec < 31536000:   return f"{int(sec/2592000)} month(s)"
        y = sec / 31536000
        if y < 1e6:          return f"{int(y):,} year(s)"
        return f"{y:.2e} years"

    return {
        "online_attack_1k_per_sec":   fmt(guesses / 1_000),
        "offline_hash_10b_per_sec":   fmt(guesses / 10_000_000_000),
        "gpu_cluster_1t_per_sec":     fmt(guesses / 1_000_000_000_000),
    }


def analyze(p: str) -> dict:
    score   = calculate_score(p)
    checks  = run_policy_checks(p)
    passed  = sum(1 for c in checks if c["passed"])
    suggestions = [c["description"] for c in checks if not c["passed"]]

    return {
        "password_length": len(p),
        "score":           score,
        "label":           strength_label(score),
        "charset_size":    charset_size(p),
        "policy_checks":   checks,
        "checks_passed":   passed,
        "checks_total":    len(checks),
        "suggestions":     suggestions,
        "crack_time":      crack_time_estimate(p),
        "is_common":       is_common_password(p),
        "has_repeats":     has_repeating_chars(p),
        "has_sequences":   has_sequential_pattern(p),
    }
