"""
password_generator.py — Suggest stronger password alternatives

Three generation strategies:
1. Random secure password   — cryptographically random, configurable charset
2. Passphrase               — random words joined by separator (easy to remember)
3. Mutated version          — takes user's weak password and strengthens it

All use `secrets` module (CSPRNG), never `random`.
"""

import secrets
import re
import string

# ---------------------------------------------------------------------------
# Word list (subset — extend with a full EFF word list for production use)
# ---------------------------------------------------------------------------
EFF_WORDS = [
    "apple","bridge","canyon","dancer","engine","forest","garden","harbor",
    "island","jungle","kitten","lemon","mirror","nebula","ocean","planet",
    "quartz","rabbit","silver","timber","umbrella","violet","walnut","xenon",
    "yellow","zebra","anchor","basket","candle","desert","ember","falcon",
    "glacier","hollow","indigo","jacket","kernel","lantern","marble","noble",
    "osprey","pillar","quiver","rocket","saddle","tunnel","update","valley",
    "wander","syntax","token","module","vector","cipher","matrix","signal",
    "vertex","beacon","carbon","delta","fabric","gravel","hammer","impact",
    "jasper","kettle","legacy","magnet","needle","offset","prism","radius",
    "scout","tundra","unique","vapor","whisper","xylem","yonder","zephyr",
    "amber","blaze","cobalt","dagger","elbow","flint","grove","haven",
    "ivory","jolt","knave","lunar","mossy","north","oaken","pearl",
    "quiet","ridge","storm","thorn","ultra","vivid","wheat","xenial",
]

CHARSETS = {
    "lower":   string.ascii_lowercase,
    "upper":   string.ascii_uppercase,
    "digits":  string.digits,
    "symbols": "!@#$%^&*()-_=+[]{}|;:,.<>?",
}


# ---------------------------------------------------------------------------
# Strategy 1: Random secure password
# ---------------------------------------------------------------------------

def generate_random(
    length: int = 16,
    use_upper: bool = True,
    use_digits: bool = True,
    use_symbols: bool = True,
) -> str:
    """
    Generate a cryptographically secure random password.
    Guarantees at least one character from each enabled class.
    """
    pool = CHARSETS["lower"]
    required = [secrets.choice(CHARSETS["lower"])]

    if use_upper:
        pool += CHARSETS["upper"]
        required.append(secrets.choice(CHARSETS["upper"]))
    if use_digits:
        pool += CHARSETS["digits"]
        required.append(secrets.choice(CHARSETS["digits"]))
    if use_symbols:
        pool += CHARSETS["symbols"]
        required.append(secrets.choice(CHARSETS["symbols"]))

    remaining = [secrets.choice(pool) for _ in range(length - len(required))]
    combined  = required + remaining
    secrets.SystemRandom().shuffle(combined)
    return "".join(combined)


# ---------------------------------------------------------------------------
# Strategy 2: Memorable passphrase
# ---------------------------------------------------------------------------

def generate_passphrase(
    num_words: int = 4,
    separator: str = "-",
    capitalise: bool = True,
    append_number: bool = True,
    append_symbol: bool = True,
) -> str:
    """
    Generate a BIP39/EFF-style passphrase.
    Example: Glacier-Beacon-Tundra-Prism-47!
    """
    words = [secrets.choice(EFF_WORDS) for _ in range(num_words)]
    if capitalise:
        words = [w.capitalize() for w in words]

    parts = [separator.join(words)]
    if append_number:
        parts.append(str(secrets.randbelow(90) + 10))   # 10–99
    if append_symbol:
        parts.append(secrets.choice("!@#$%&*"))

    return "".join(parts)


# ---------------------------------------------------------------------------
# Strategy 3: Mutate a weak password into a stronger one
# ---------------------------------------------------------------------------

LEET_MAP = {
    'a': '@', 'e': '3', 'i': '!', 'o': '0',
    's': '$', 't': '7', 'l': '1', 'b': '6',
}

def mutate_password(password: str) -> str:
    """
    Strengthen a user's existing password:
    - Apply leet-speak substitutions randomly
    - Append a random 2-digit number + symbol
    - Capitalise a random letter
    - Pad to at least 14 chars if needed
    """
    chars = list(password)

    # Leet-speak on ~40% of eligible chars
    for i, ch in enumerate(chars):
        if ch.lower() in LEET_MAP and secrets.randbelow(10) < 4:
            chars[i] = LEET_MAP[ch.lower()]

    # Capitalise a random lowercase letter
    lower_indices = [i for i, c in enumerate(chars) if c.islower()]
    if lower_indices:
        idx = secrets.choice(lower_indices)
        chars[idx] = chars[idx].upper()

    # Append digits + symbol
    suffix = str(secrets.randbelow(90) + 10) + secrets.choice("!@#$%&*")
    result = "".join(chars) + suffix

    # Pad if still short
    pool = string.ascii_letters + string.digits + "!@#$%"
    while len(result) < 14:
        result += secrets.choice(pool)

    return result


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def suggest_alternatives(password: str, count: int = 3) -> list[dict]:
    """
    Return `count` alternative passwords across all strategies,
    each with a label, the generated password, and a brief rationale.
    """
    suggestions = []

    # One random password
    suggestions.append({
        "strategy":  "Random Secure",
        "password":  generate_random(length=16),
        "rationale": "16-char random password from 94-char pool — ~104 bits of entropy.",
    })

    # One passphrase
    suggestions.append({
        "strategy":  "Passphrase",
        "password":  generate_passphrase(num_words=4),
        "rationale": "4 random words — easy to remember, hard to crack (~50 bits).",
    })

    # Mutated version of original
    if password:
        suggestions.append({
            "strategy":  "Strengthened Original",
            "password":  mutate_password(password),
            "rationale": "Your password with leet-speak, capitalisation, and a suffix applied.",
        })

    # Extra random if count > 3
    for _ in range(max(0, count - 3)):
        suggestions.append({
            "strategy":  "Random Secure",
            "password":  generate_random(length=20),
            "rationale": "20-char random password — ~130 bits of entropy.",
        })

    return suggestions[:count]


if __name__ == "__main__":
    print("=== Password Generator Demo ===\n")
    print(f"Random (16):     {generate_random(16)}")
    print(f"Random (20):     {generate_random(20)}")
    print(f"Passphrase (4):  {generate_passphrase(4)}")
    print(f"Passphrase (5):  {generate_passphrase(5, separator='_')}")
    print(f"Mutated:         {mutate_password('mypassword')}")
    print()
    print("Alternatives for 'hunter2':")
    for s in suggest_alternatives("hunter2"):
        print(f"  [{s['strategy']}]  {s['password']}")
        print(f"    → {s['rationale']}")
