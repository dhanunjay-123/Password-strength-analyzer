"""
entropy.py — Password entropy & uniqueness analysis
"""

import math
import re
from collections import Counter


def charset_size(password: str) -> int:
    size = 0
    if re.search(r'[a-z]', password): size += 26
    if re.search(r'[A-Z]', password): size += 26
    if re.search(r'[0-9]', password): size += 10
    if re.search(r'[^a-zA-Z0-9]', password): size += 32
    return size or 1


def bit_entropy(password: str) -> float:
    """H = L * log2(N)  — theoretical max entropy."""
    if not password:
        return 0.0
    return len(password) * math.log2(charset_size(password))


def shannon_entropy(password: str) -> float:
    """Actual character-distribution entropy."""
    if not password:
        return 0.0
    freq = Counter(password)
    n = len(password)
    return -sum((c / n) * math.log2(c / n) for c in freq.values())


def uniqueness_ratio(password: str) -> float:
    """Ratio of unique characters to total length (1.0 = all unique)."""
    if not password:
        return 0.0
    return len(set(password)) / len(password)


def entropy_report(password: str) -> dict:
    bits    = bit_entropy(password)
    shannon = shannon_entropy(password)
    pool    = charset_size(password)
    uniq    = uniqueness_ratio(password)

    if bits < 28:   rating = "Very Weak"
    elif bits < 36: rating = "Weak"
    elif bits < 60: rating = "Reasonable"
    elif bits < 80: rating = "Strong"
    else:           rating = "Very Strong"

    return {
        "bit_entropy":      round(bits, 2),
        "shannon_entropy":  round(shannon, 4),
        "charset_pool":     pool,
        "unique_chars":     len(set(password)),
        "uniqueness_ratio": round(uniq, 3),
        "length":           len(password),
        "rating":           rating,
    }
