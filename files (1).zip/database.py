"""
database.py — SQLite persistence
Stores hashed passwords (SHA-256), scores, labels, and policy results.
NEVER stores plaintext passwords.

Tables:
  analysis_history  — one row per analysis run
  policy_results    — per-check breakdown for each run
  password_vault    — hashed previously-used passwords per "user"
                      (for reuse prevention)
"""

import hashlib
import sqlite3
from datetime import datetime
from pathlib import Path

DB_PATH = Path(__file__).parent / "database.db"


def _conn() -> sqlite3.Connection:
    c = sqlite3.connect(DB_PATH)
    c.row_factory = sqlite3.Row
    return c


def init_db() -> None:
    with _conn() as c:
        c.executescript("""
            CREATE TABLE IF NOT EXISTS analysis_history (
                id        INTEGER PRIMARY KEY AUTOINCREMENT,
                timestamp TEXT    NOT NULL,
                score     INTEGER NOT NULL,
                label     TEXT    NOT NULL,
                pwd_hash  TEXT    NOT NULL
            );

            CREATE TABLE IF NOT EXISTS policy_results (
                id         INTEGER PRIMARY KEY AUTOINCREMENT,
                history_id INTEGER REFERENCES analysis_history(id),
                check_name TEXT    NOT NULL,
                passed     INTEGER NOT NULL
            );

            CREATE TABLE IF NOT EXISTS password_vault (
                id        INTEGER PRIMARY KEY AUTOINCREMENT,
                username  TEXT    NOT NULL,
                pwd_hash  TEXT    NOT NULL,
                added_at  TEXT    NOT NULL,
                UNIQUE(username, pwd_hash)
            );
        """)
        c.commit()


def _sha256(password: str) -> str:
    return hashlib.sha256(password.encode()).hexdigest()


def save_result(password: str, score: int, label: str,
                checks: list | None = None) -> int:
    ts = datetime.utcnow().isoformat(timespec="seconds") + "Z"
    with _conn() as c:
        cur = c.execute(
            "INSERT INTO analysis_history (timestamp, score, label, pwd_hash) VALUES (?,?,?,?)",
            (ts, score, label, _sha256(password))
        )
        hid = cur.lastrowid
        if checks:
            c.executemany(
                "INSERT INTO policy_results (history_id, check_name, passed) VALUES (?,?,?)",
                [(hid, ch["check"], int(ch["passed"])) for ch in checks]
            )
        c.commit()
    return hid


# ---------------------------------------------------------------------------
# Reuse prevention
# ---------------------------------------------------------------------------

def remember_password(username: str, password: str) -> bool:
    """Store a hashed password for a user. Returns True if newly added."""
    h = _sha256(password)
    ts = datetime.utcnow().isoformat(timespec="seconds") + "Z"
    try:
        with _conn() as c:
            c.execute(
                "INSERT INTO password_vault (username, pwd_hash, added_at) VALUES (?,?,?)",
                (username, h, ts)
            )
            c.commit()
        return True
    except sqlite3.IntegrityError:
        return False   # already stored (UNIQUE constraint)


def was_used_before(username: str, password: str) -> bool:
    """Return True if this password hash was previously stored for this user."""
    h = _sha256(password)
    with _conn() as c:
        row = c.execute(
            "SELECT id FROM password_vault WHERE username=? AND pwd_hash=?",
            (username, h)
        ).fetchone()
    return row is not None


def get_user_history_count(username: str) -> int:
    with _conn() as c:
        row = c.execute(
            "SELECT COUNT(*) AS n FROM password_vault WHERE username=?", (username,)
        ).fetchone()
    return row["n"]


# ---------------------------------------------------------------------------
# History & stats
# ---------------------------------------------------------------------------

def get_history(limit: int = 20) -> list[dict]:
    with _conn() as c:
        rows = c.execute(
            "SELECT timestamp, score, label FROM analysis_history ORDER BY id DESC LIMIT ?",
            (limit,)
        ).fetchall()
    return [dict(r) for r in rows]


def get_stats() -> dict:
    with _conn() as c:
        row = c.execute("""
            SELECT COUNT(*) AS total, AVG(score) AS avg,
                   MIN(score) AS mn,   MAX(score) AS mx
            FROM analysis_history
        """).fetchone()
        dist = c.execute("""
            SELECT label, COUNT(*) AS n FROM analysis_history
            GROUP BY label ORDER BY n DESC
        """).fetchall()
    return {
        "total":              row["total"],
        "avg_score":          round(row["avg"] or 0, 1),
        "min_score":          row["mn"] or 0,
        "max_score":          row["mx"] or 0,
        "label_distribution": {r["label"]: r["n"] for r in dist},
    }
