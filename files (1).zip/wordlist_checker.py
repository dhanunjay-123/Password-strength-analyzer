"""
wordlist_checker.py — Common password & breach detection
"""

import hashlib
import re

COMMON_PASSWORDS: set[str] = {
    "password","123456","qwerty","abc123","letmein","monkey","1234567890",
    "password1","iloveyou","admin","welcome","login","master","dragon",
    "passw0rd","sunshine","princess","football","shadow","superman","michael",
    "qwerty123","password123","hello","charlie","donald","test","guest","root",
    "pass","12345","111111","000000","654321","123123","696969","batman",
    "access","secret","baseball","soccer","hockey","killer","george","jordan",
    "hunter","buster","thomas","tigger","robert","daniel","jessica","message",
    "freedom","computer","ranger","pepper","amanda","andrew","joshua","123qwe",
    "pass123","changeme","letme1n","trustno1","solo","star","manager","network",
    "mustang","harley","ninja","samurai","qazwsx","1q2w3e","zxcvbn","asdfgh",
    "abcdef","1111","1234","12345678","123456789","password!","pass1234",
    "qwerty1","test123","admin123","administrator","root123","welcome1",
    "superman1","monkey1","dragon1","shadow1","master1","letmein1","iloveyou1",
}

WEAK_PATTERNS = [
    re.compile(r'^\d+$'),
    re.compile(r'^[a-zA-Z]+$'),
    re.compile(r'^(.)\1+$'),
    re.compile(r'^(012|123|234|345|456|567|678|789|890)+$'),
]


def normalise(p: str) -> str:
    return p.strip().lower()

def is_common_password(p: str) -> bool:
    return normalise(p) in COMMON_PASSWORDS

def matches_weak_pattern(p: str) -> bool:
    return any(pat.match(p) for pat in WEAK_PATTERNS)

def sha1_parts(p: str) -> tuple[str, str]:
    digest = hashlib.sha1(p.encode()).hexdigest().upper()
    return digest[:5], digest[5:]

def check_hibp_api(p: str) -> dict:
    """k-anonymity HIBP lookup — never sends full password."""
    try:
        import urllib.request
        prefix, suffix = sha1_parts(p)
        req = urllib.request.Request(
            f"https://api.pwnedpasswords.com/range/{prefix}",
            headers={"User-Agent": "PasswordAnalyzer/2.0"}
        )
        with urllib.request.urlopen(req, timeout=5) as resp:
            body = resp.read().decode()
        for line in body.splitlines():
            h, count = line.split(":")
            if h == suffix:
                return {"breached": True, "count": int(count)}
        return {"breached": False, "count": 0}
    except Exception as e:
        return {"breached": False, "count": -1, "error": str(e)}

def wordlist_report(p: str) -> dict:
    prefix, _ = sha1_parts(p)
    return {
        "is_common_password":   is_common_password(p),
        "matches_weak_pattern": matches_weak_pattern(p),
        "sha1_prefix":          prefix,
    }
